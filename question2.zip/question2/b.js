/***** address *****/
// npm-library
const Wallet = require('ethereumjs-wallet');
const keccak256 = require('js-sha3').keccak256;

// keypair
const wallet = Wallet.generate();
 
// privKey
const privKey = wallet.getPrivateKeyString();
console.log("privKey:", privKey);
 
// pubKey
const pubKey = wallet.getPublicKeyString();
console.log("pubKey:", pubKey);


// step 2:  public_key_hash = Keccak-256(public_key)

const address = keccak256(pubKey).slice(64 - 40);

          

// step 3:  address = ‘0x’ + last 20 bytes of public_key_hash
var Address = address.toString('hex');


//address = '0x' + address ;
var hexAddress = "0x".concat(Address);

console.log("address:",hexAddress );
//console.log("address:", address);

